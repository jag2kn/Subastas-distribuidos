package Socket;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

public class PedidosServidor {
	private Socket socket;
	private static final PedidosServidor INSTANCE = new PedidosServidor();

	private PedidosServidor() {
		
	}
	public static PedidosServidor getInstance(){
		return INSTANCE;
	} 

	public boolean loggin(String usuario, String contrasenia) {
		boolean result = false;
		try {
			InetAddress direccion = InetAddress.getByName("localhost");
			socket = new Socket(direccion, 9955);
			DataOutputStream out = new DataOutputStream(
					socket.getOutputStream());
			DataInputStream in = new DataInputStream(socket.getInputStream());

			if (usuario != null)
				if (!usuario.isEmpty()) { // caso para loggin
					out.writeUTF("loggin\n" + usuario + "\n" + contrasenia);

				} // recibe la notificacion del servidor
			String re = in.readUTF().toString();
			if (re.equalsIgnoreCase("true"))
				result = true;

		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	public String getEstado() {
		String result = "";
		try {
			InetAddress direccion = InetAddress.getByName("localhost");
			socket = new Socket(direccion, 9955);
			DataOutputStream out = new DataOutputStream(
					socket.getOutputStream());
			DataInputStream in = new DataInputStream(socket.getInputStream());

			out.writeUTF("getEstado");

			result = in.readUTF().toString();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}

	public boolean bid(int cantidad) {
		boolean result = false;
		try {
			InetAddress direccion = InetAddress.getByName("localhost");
			socket = new Socket(direccion, 9955);
			DataOutputStream out = new DataOutputStream(
					socket.getOutputStream());
			DataInputStream in = new DataInputStream(socket.getInputStream());

			out.writeUTF("Bid\n" + cantidad);
			String re = in.readUTF().toString();
			if (re.equalsIgnoreCase("true"))
				result = true;

		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
}
