package GUI;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Socket.PedidosServidor;

public class VentanaPrincipal extends JFrame implements ActionListener {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final VentanaPrincipal INSTANCE = new VentanaPrincipal();
	private JTextField usuario;
	private JPasswordField contrasenia;
	private JButton loggin;

	private VentanaPrincipal() {
		init();
		setup();
	}

	public static VentanaPrincipal getInstance() {
		return INSTANCE;
	}

	public void init() {
		usuario = new JTextField(100);
		contrasenia = new JPasswordField(100);
		loggin = new JButton("Loggin");
	}

	public void setup() {
		setSize(200, 300);
		setTitle("Loggin");
		usuario.setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createLineBorder(Color.BLACK), "Usser", 2, 2));
		contrasenia.setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createLineBorder(Color.BLACK), "Password", 2, 2));
		getContentPane().setBackground(Color.WHITE);

		setLayout(null);
		setResizable(false);
		usuario.setBounds(50, 50, 100, 35);

		contrasenia.setBounds(50, 90, 100, 35);
		loggin.setBounds(55, 130, 90, 25);
		add(usuario);
		add(contrasenia);
		add(loggin);
		setVisible(true);
		loggin.addActionListener(this);
	}

	@SuppressWarnings("deprecation")
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == loggin) {
			if (PedidosServidor.getInstance().loggin(usuario.getText(),
					contrasenia.getText())) {
				usuario.setText("");
				contrasenia.setText("");
				VentanaSubasta.getInstance().setVisible(true);
				setVisible(false);
			} else
				JOptionPane.showMessageDialog(this, "No se pudo conectar");
		}

	}

}
