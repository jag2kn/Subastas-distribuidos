package GUI;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import Socket.PedidosServidor;

public class VentanaSubasta extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = -8840605443438164298L;
	public static final VentanaSubasta INSTANCE = new VentanaSubasta();
	private JButton state, bid, loggout;
	private JTextArea areaState;
	private JScrollPane scrollState;

	private VentanaSubasta() {
		init();
		setup();
	}

	public static VentanaSubasta getInstance() {
		return INSTANCE;
	}

	public void init() {
		state = new JButton("Get State");
		bid = new JButton("Bid!");
		loggout = new JButton("Loggout");
		areaState = new JTextArea();
		scrollState = new JScrollPane(areaState);
	}

	public void setup() {
		setSize(300, 400);
		getContentPane().setBackground(Color.WHITE);
		scrollState.setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createLineBorder(Color.BLACK), "State", 2, 2));
		scrollState.setBackground(Color.WHITE);
		areaState.setEditable(false);
		setLayout(null);// 9955
		setResizable(false);
		loggout.setBounds(0, 0, 100, 25);
		scrollState.setBounds(50, 30, 200, 300);
		state.setBounds(50, 335, 125, 25);
		bid.setBounds(180, 335, 70, 25);
		add(loggout);
		add(scrollState);
		add(state);
		add(bid);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == loggout) {
			state.setText("");
			VentanaPrincipal.getInstance().setVisible(true);
			setVisible(false);
		} else if (e.getSource() == state) {
			areaState.setText("");
			String[] lines = PedidosServidor.getInstance().getEstado()
					.split("\n");
			for (String line : lines)
				areaState.append(line + "\n");
		} else if (e.getSource() == bid) {
			String valor = JOptionPane.showInputDialog("Ingrese el valor");
			try {
				int value = Integer.parseInt(valor);
				if (PedidosServidor.getInstance().bid(value))
					JOptionPane.showMessageDialog(this, "Puja Realizada");
				else
					JOptionPane.showMessageDialog(this,
							"No se pudo realizar esta accion");

			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(this, "Ingrese un numero");
			}
		}

	}

}
