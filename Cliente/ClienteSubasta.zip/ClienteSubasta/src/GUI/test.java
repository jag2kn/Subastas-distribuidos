package GUI;

public class test {

	public static void main(String[] args) {
		VentanaPrincipal v = VentanaPrincipal.getInstance();

	}

}
